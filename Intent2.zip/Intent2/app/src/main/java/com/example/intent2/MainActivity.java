package com.example.intent2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    EditText edtSoA, edtSoB;
    Button btnTinh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Ánh xạ biến
        edtSoA = findViewById(R.id.edtSoA);
        edtSoB = findViewById(R.id.edtSoB);
        btnTinh =findViewById(R.id.btnTInh);

        btnTinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myintent= new Intent(MainActivity.this , ResultActivity.class) ;
                    Bundle bundle1 = new Bundle(); //Tạo biến đóng gói chuyển dữ liệu từ MainAc sang ResultAc
                    int a = Integer.parseInt(edtSoA.getText() + "");
                    int b = Integer.parseInt(edtSoB.getText() + "");
                    bundle1.putInt("soa", a);// chuyển đổi chúng thành số nguyên và lưu trữ trong các biến a , b
                    bundle1.putInt("sob", b);
                    myintent.putExtra("mybackage", bundle1);
                    //Đặt bundle1 vào myintent với key là "mybackage" để chuyển dữ liệu từ một Activity này sang một Activity khác.
                    startActivity(myintent);
            }
        });
    }
}