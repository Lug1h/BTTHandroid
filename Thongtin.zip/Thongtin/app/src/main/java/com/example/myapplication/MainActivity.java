package com.example.myapplication;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText edtName, edtCCCD, edtBosung;
    Button btnSubmit;
    RadioGroup rdGBangcap;
    CheckBox ckcTruyen, ckcNgheNhac, ckcXem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ánh xạ id
        edtName = findViewById(R.id.edtName);
        edtCCCD = findViewById(R.id.edtCCCD);
        edtBosung = findViewById(R.id.edtBosung);
        rdGBangcap = findViewById(R.id.rdGBangcap);
        ckcTruyen = findViewById(R.id.ckcTruyen);
        ckcNgheNhac = findViewById(R.id.ckcNgheNhac);
        ckcXem = findViewById(R.id.ckcXem);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Lấy thông tin họ tên
                String hoten = edtName.getText().toString().trim();
                if (hoten.length() <= 10) {
                    Toast.makeText(MainActivity.this, "Vui lòng điền cả họ và tên. (Lớn hơn 10 ký tự) ", Toast.LENGTH_SHORT).show();
                    edtName.requestFocus();
                    edtName.selectAll();
                    return;
                }

                // Lấy thông tin CCCD
                String CCCD = edtCCCD.getText().toString().trim();
                if (CCCD.length() != 12) {
                    Toast.makeText(MainActivity.this, "Căn cước công dân phải là 12 số . Vui lòng nhập lại", Toast.LENGTH_SHORT).show();
                    edtCCCD.requestFocus();
                    edtCCCD.selectAll();
                    return;
                }

                // Lấy thông tin bằng cấp
                int idselect = rdGBangcap.getCheckedRadioButtonId();
                RadioButton radselect = findViewById(idselect);
                String bangcap = radselect.getText().toString();

                // Lấy thông tin sở thích
                StringBuilder sothich = new StringBuilder();
                if (ckcTruyen.isChecked())
                    sothich.append(ckcTruyen.getText().toString()).append("-");

                if (ckcXem.isChecked())
                    sothich.append(ckcXem.getText().toString()).append("-");

                if (ckcNgheNhac.isChecked())
                    sothich.append(ckcNgheNhac.getText().toString()).append("-");

                // Lấy thông tin bổ sung
                String bosung = edtBosung.getText().toString().trim();
                String tonghop = "Họ và tên: " + hoten + "\n" +
                        "CCCD: " + CCCD + "\n" +
                        "Bằng cấp: " + bangcap + "\n" +
                        "Sở thích: " + sothich.toString() + "\n" +
                        "Thông tin bổ sung: " + bosung + "\n";

                // Tạo dialog và hiển thị thông tin
                AlertDialog.Builder mydialog = new AlertDialog.Builder(MainActivity.this);
                mydialog.setTitle("THÔNG TIN CÁ NHÂN");
                mydialog.setMessage(tonghop);
                mydialog.setPositiveButton("Đóng", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                mydialog.create().show();
            }
                @Override
            public void onBackPressed() {
                AlertDialog.Builder b =new AlertDialog.Builder(MainActivity.this);
                b.setTitle("Question");
                b.setMessage("Are you sure you want to exit?");
                b.setIcon(R.drawable.ic_launcher_background);
                b.setPositiveButton("Yes", new DialogInterface.
                        OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        finish();
                    }});
                b.setNegativeButton("No", new
                        DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                dialog.cancel();
                            }
                        });
                b.create().show();
            }
        });
    }
}
