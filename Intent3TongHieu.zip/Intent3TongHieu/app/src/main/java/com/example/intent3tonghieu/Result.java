package com.example.intent3tonghieu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Result extends AppCompatActivity {
    EditText edtNhanA, edtNhanB;
    Button btnTong,btnHieu;
    Intent myintent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_result);
        edtNhanA = findViewById(R.id.edtNhanA);
        edtNhanB = findViewById(R.id.edtNhanB);
        btnTong = findViewById(R.id.btnTraveTong);
        btnHieu = findViewById(R.id.btnTraveHieu);
        //Nhận intent
        myintent = getIntent();
        //lấy dữ liệu khỏi intent
        int a = myintent.getIntExtra("soA", 0);
        int b = myintent.getIntExtra("soB", 0);
        edtNhanA.setText(a+ "");
        edtNhanB.setText(b+ "");
        btnTong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    //Xử lý kết quả
                    int sum = a + b;
                    //Đẩy kết quả trở về intent
                    myintent.putExtra("kq", sum);
                    //trả intent trở về
                    setResult(33, myintent);
                    //thoát result activity quay về main
                    finish();

            }
        });
        btnHieu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Xử lý kết quả
                int sub = a - b;
                //Đẩy kết quả trở về intent
                myintent.putExtra("kq", sub);
                //trả intent trở về
                setResult(34, myintent);
                //thoát result activity quay về main
                finish();

            }
        });
    }
}